#!/bin/bash

# Get the directory of the current script
scriptDir="$(dirname "$(readlink -f "$0")")"
targetFolder="$scriptDir/../../libs"

# Libraries to publish in the specified sequence
libraries=("core" "prisma" "sdk", "extensions")

# Publish libraries in the specified sequence
for lib in "${libraries[@]}"; do
    libPath="$targetFolder/$lib"
    if [ -d "$libPath" ]; then
        bash "$scriptDir/publish.sh" "$lib"
    fi
done

# Publish remaining libraries
for libPath in "$targetFolder"/*; do
    if [ -d "$libPath" ]; then
        libName=$(basename "$libPath")
        if [[ ! " ${libraries[@]} " =~ " $libName " && "$libName" != "dist" ]]; then
            bash "$scriptDir/publish.sh" "$libName"
        fi
    fi
done

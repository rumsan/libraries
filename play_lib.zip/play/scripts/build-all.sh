#!/bin/bash

# Get the directory of the current script
scriptDir="$(dirname "$(readlink -f "$0")")"
targetFolder="$scriptDir/../../libs"

# Iterate over subfolders in the target folder
for libPath in "$targetFolder"/*; do
    if [ -d "$libPath" ]; then  # Check if it's a directory
        libName=$(basename "$libPath")
        if [ "$libName" = "dist" ]; then
            echo "Skipping $libName"
            continue
        fi
        nx build "$libName"
    fi
done

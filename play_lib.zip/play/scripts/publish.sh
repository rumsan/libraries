#!/bin/bash

# Paths to TypeScript libs folder and distribution folder
baseFolder="/home/argahv/Documents/Web/Rumsan/libraries"
typescriptLibsFolder="$baseFolder/libs"
distributionFolder="$baseFolder/dist/libs"
npmrcPath="$baseFolder/play/.npmrc"

# Function to read version from package.json
read_version() {
    if [ -f "$typescriptLibsFolder/$1/package.json" ]; then
        local version=$(jq -r '.version' "$typescriptLibsFolder/$1/package.json")
        echo "$version"
    else
        echo "Error: package.json for library '$1' not found in $typescriptLibsFolder/$1"
        exit 1
    fi
}

# Function to update version in package.json
update_version() {
    jq --arg newVersion "$2" '.version = $newVersion' "$typescriptLibsFolder/$1/package.json" > tmp.json && mv tmp.json "$typescriptLibsFolder/$1/package.json"
}

# Function to increment patch version
# increment_patch_version() {
#     local version="$1"
#     local major=$(echo $version | cut -d. -f1)
#     local minor=$(echo $version | cut -d. -f2)
#     local patch=$(echo $version | cut -d. -f3)
#     ((patch++))
#     echo "$major.$minor.$patch"
# }

increment_patch_version() {
    local version="$1"
    local patch=$(echo "$version" | awk -F. '{print $3}')
    local new_patch=$((patch + 1))
    echo "$(echo "$version" | awk -F. '{print $1"."$2}').$new_patch"
}

# Function to revert version in package.json
revert_version() {
    jq --arg origVersion "$2" '.version = $origVersion' "$typescriptLibsFolder/$1/package.json" > tmp.json && mv tmp.json "$typescriptLibsFolder/$1/package.json"
}

# Check if library name is provided as argument
if [ -n "$1" ]; then
    libName="$1"
else
    # Ask user for library name
    read -p "Enter library name: " libName
fi

# Check if library folder exists
if [ ! -d "$typescriptLibsFolder/$libName" ]; then
    echo "Error: Library folder '$libName' not found in $typescriptLibsFolder"
    exit 1
fi

# Store original version
originalVersion=$(read_version "$libName")

# Display current version
echo "Reading version from package.json..."
oldVersion="$originalVersion"

# Automatically increment patch version
newVersion=$(increment_patch_version "$oldVersion")

# Update version in package.json
echo "Updating version in package.json..."
update_version "$libName" "$newVersion"

# Step 1: Run nx build
echo "Building library $libName with new version $newVersion..."
cd "$typescriptLibsFolder"
nx build "$libName"


# Step 2: Copy .npmrc to dist folder
echo "Copying .npmrc to dist folder..."
cp "$npmrcPath" "$distributionFolder/$libName"

# Step 3: Navigate to specific library folder within dist folder
cd "$distributionFolder/$libName"

# Display summary
echo "Publishing Summary:"
echo "  Library Name: $libName"
echo "  Old Version: $oldVersion"
echo "  New Version: $newVersion"

# Confirm before publishing
read -p "Do you want to proceed with publishing? (y/n): " confirm
if [ "$confirm" != "y" ]; then
    echo "Publishing aborted."
    # Revert version in package.json
    revert_version "$libName" "$originalVersion"
    echo "Version reverted to: $originalVersion"
    exit 1
fi

# Step 4: Publish npm package
echo "Publishing npm package..."
npm publish

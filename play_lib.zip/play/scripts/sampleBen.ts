import { faker } from '@faker-js/faker';
import * as fs from 'fs';
import readline from 'readline';
import { v4 as uuidv4 } from 'uuid';
import * as XLSX from 'xlsx';

export type Entry = {
    id?: number;
    uuid?: string;
    gender?: string;
    walletAddress?: string;
    birthDate?: string;
    location?: string;
    latitude?: number;
    longitude?: number;
    extras?: Record<string, any>;
    notes?: string;
    bankedStatus?: string;
    internetStatus?: string;
    phoneStatus?: string;
    piiData?: TPIIData;
    createdAt?: string;
    updatedAt?: Date;
    deletedAt?: Date;
    isVerified?: boolean
};

export type TPIIData = {
    name?: string;
    phone?: string;
    email?: string;
    extras?: Record<string, any>;
};

const generate_ethereum_address = (): string => {
    const characters = 'abcdef0123456789';
    let address = '0x';

    for (let i = 0; i < 40; i++) {
        address += characters[Math.floor(Math.random() * characters.length)];
    }

    return address;
};

const generateData = async (numberOfEntries: number): Promise<Entry[]> => {
    let data: Entry[] = [];
    let id = 1;

    for (let i = 0; i < numberOfEntries; i++) {
        const gender = faker.helpers.arrayElement(['MALE', 'FEMALE', 'OTHER']);

        const now = new Date();
        console.log({ now });

        data.push({
            id: id++,
            createdAt: faker.date.recent().toISOString(), // Set createdAt to the current date/time
            uuid: uuidv4(),
            gender: gender,
            birthDate: faker.date
                .birthdate({ min: 18, max: 65, mode: 'age' })
                .toISOString()
                .split('T')[0],
            location: faker.location.city() + ', ' + faker.location.country(),
            latitude: faker.location.latitude(),
            longitude: faker.location.longitude(),
            walletAddress: generate_ethereum_address(),
            notes: faker.lorem.sentence(),
            bankedStatus: faker.helpers.arrayElement([
                'UNKNOWN',
                'UNBANKED',
                'BANKED',
                'UNDER_BANKED',
            ]),
            internetStatus: faker.helpers.arrayElement([
                'UNKNOWN',
                'NO_INTERNET',
                'HOME_INTERNET',
                'MOBILE_INTERNET',
            ]),
            phoneStatus: faker.helpers.arrayElement([
                'UNKNOWN',
                'NO_PHONE',
                'FEATURE_PHONE',
                'SMART_PHONE',
            ]),
            extras: {
                home: faker.location.streetAddress(),
                work: faker.location.secondaryAddress(),
            },
            piiData: {
                name: faker.person.fullName(),
                phone: faker.phone.number(),
                email: faker.internet.email(),
                extras: {
                    bank: faker.helpers.arrayElement([
                        'Himalayan Bank',
                        'Laxmi Bank',
                        'Nabil Bank',
                        'Global IME',
                        'Nepal Bank Limited',
                    ]),
                    account: faker.finance.accountNumber(),
                },
            },
            isVerified: false
        });
    }
    return data;
};

const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout,
});

rl.question(
    'How many samples do you want to generate? ',
    (numberOfSamplesAnswer) => {
        const numberOfSamples = parseInt(numberOfSamplesAnswer);
        if (!isNaN(numberOfSamples) && numberOfSamples > 0) {
            rl.question(
                'Do you want to save the file as JSON or Excel? (Type "JSON" or "Excel") ',
                async (fileTypeAnswer) => {
                    const fileType = fileTypeAnswer.trim().toUpperCase();
                    if (fileType === 'JSON' || fileType === 'EXCEL') {
                        const data = generateData(numberOfSamples);
                        saveDataToFile(await data, fileType);
                    } else {
                        console.log('Please enter "JSON" or "Excel" for file type.');
                    }
                    rl.close();
                }
            );
        } else {
            console.log('Please enter a valid number greater than 0.');
            rl.close();
        }
    }
);

const flattenJson = (data: any, prefix = ''): any => {
    const flattenedData: any = {};

    for (const key in data) {
        if (typeof data[key] === 'object' && data[key] !== null) {
            const flatObject = flattenJson(data[key], `${prefix}${key}.`);
            Object.assign(flattenedData, flatObject);
        } else {
            flattenedData[`${prefix}${key}`] = data[key];
        }
    }

    return flattenedData;
};

const saveDataToFile = (data: Entry[], fileType: string) => {
    const fileName =
        fileType === 'JSON' ? './play/sampleBen.json' : './play/sampleBen.xlsx';

    if (fileType === 'JSON') {
        fs.writeFile(fileName, JSON.stringify(data, null, 2), (err) => {
            if (err) throw err;
            console.log('Data has been saved to sampleBen.json');
        });
    } else {
        const flattenedData = data.map((entry) => flattenJson(entry));
        const worksheet = XLSX.utils.json_to_sheet(flattenedData);
        console.log(worksheet);
        const workbook = XLSX.utils.book_new();
        XLSX.utils.book_append_sheet(workbook, worksheet, 'Entries');
        XLSX.writeFile(workbook, fileName);
        console.log('Data has been saved to sampleBen.xlsx');
    }
};
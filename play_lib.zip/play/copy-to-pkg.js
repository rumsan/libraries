const fs = require('fs').promises;
const path = require('path');

const sourceFolder =
  '/home/argahv/Documents/Web/Rumsan/libraries/dist/libs/prisma';
const destinationFolder =
  '/home/argahv/Documents/Web/Rumsan/rahat-platform-nx/node_modules/@rumsan/prisma';
// '/home/argahv/Documents/Projects/Rumsan/rahat/web/rahat-platform-nx/node_modules/@rumsan';

const fileOperations = {
  async copyFolderRecursive(sourceFolder, destinationFolder) {
    try {
      // Ensure that the destination folder exists
      await fileOperations.ensureFolderExists(destinationFolder);

      // Remove all files from the destination folder
      await fileOperations.clearDestination(destinationFolder);

      // Read the list of items in the source folder
      const items = await fs.readdir(sourceFolder);

      // Loop through the items
      for (const item of items) {
        const sourcePath = path.join(sourceFolder, item);
        const destinationPath = path.join(destinationFolder, item);

        // Get the stats of the item to determine if it's a file or directory
        const itemStats = await fs.stat(sourcePath);

        if (itemStats.isDirectory()) {
          // Recursively copy subfolder
          await fileOperations.copyFolderRecursive(sourcePath, destinationPath);
        } else if (itemStats.isFile()) {
          // Copy file without checking modification time
          await fs.copyFile(sourcePath, destinationPath);
          console.log(`Copied: ${destinationPath}`);
        }
      }

      console.log(
        `Copying from ${sourceFolder} to ${destinationFolder} completed.`,
      );
    } catch (error) {
      console.error('Error:', error.message);
    }
  },

  async clearDestination(destinationFolder) {
    try {
      // Read the list of items in the destination folder
      const items = await fs.readdir(destinationFolder);

      // Loop through the items and remove files
      for (const item of items) {
        const itemPath = path.join(destinationFolder, item);
        const itemStats = await fs.stat(itemPath);

        if (itemStats.isFile()) {
          await fs.unlink(itemPath);
          console.log(`Removed: ${itemPath}`);
        }
      }
    } catch (error) {
      console.error('Error clearing destination:', error.message);
    }
  },

  async ensureFolderExists(folderPath) {
    try {
      await fs.mkdir(folderPath, { recursive: true });
    } catch (error) {
      if (error.code !== 'EEXIST') {
        throw error;
      }
    }
  },
};

// Start the copy process
fileOperations.copyFolderRecursive(sourceFolder, destinationFolder);
